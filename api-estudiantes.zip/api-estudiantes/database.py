import psycopg2
from psycopg2.extras import RealDictCursor
from contextlib import contextmanager

# Configuración de conexión
DB_CONFIG = {
    'host': 'localhost',
    'database': 'escuela_db',
    'user': 'postgres',
    'password': 'root'
}

@contextmanager
def get_db_connection():
    """
    Conecta temporalmente a la base de datos y cierra automáticamente.
    """
    conn = psycopg2.connect(**DB_CONFIG, cursor_factory=RealDictCursor)
    try:
        yield conn
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()